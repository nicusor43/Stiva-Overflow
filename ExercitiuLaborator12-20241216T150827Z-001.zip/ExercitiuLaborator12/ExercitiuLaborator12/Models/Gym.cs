﻿using System.ComponentModel.DataAnnotations;

namespace ExercitiuLaborator12.Models
{
    public class Gym
    {
        [Key]
        public int Id { get; set; }
    }
}
