﻿using Microsoft.AspNetCore.Mvc;

namespace ExercitiuLaborator12.Controllers
{
    public class MembershipsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
